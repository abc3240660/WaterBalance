//       10        20        30        40        50        60        70
//--*----*----*----*----*----*----*----*----*----*----*----*----*----*----*----*

/******************************************************************************
 * A library for MOBIT Protocol
 * This file is about the MOBIT Protocol API
 *
 * Copyright (c) 2019 Mobit technology inc.
 * @Author       : Damon
 * @Create time  : 02/20/2019
******************************************************************************/
#include <stdio.h>
#include <string.h>
#include "013_Protocol.h"

const char* cmd_list[] = {
	CMD_DEV_REGISTER,
	CMD_HEART_BEAT,
	CMD_QUERY_PARAMS,
	CMD_RING_ALARM,
	CMD_UNLOCK_DOOR,
	CMD_DOOR_LOCKED,
	CMD_DOOR_UNLOCKED,
	CMD_JUMP_LAMP,
	CMD_CALYPSO_UPLOAD,
	CMD_ENGINE_START,
	CMD_INVALID_MOVE,
	CMD_REPORT_GPS,
	CMD_IAP_SUCCESS,
	CMD_CHARGE_STARTED,
	CMD_CHARGE_STOPED,
	CMD_DEV_SHUTDOWN,
	CMD_QUERY_GPS,
	CMD_IAP_UPGRADE,
	CMD_MP3_UPDATE,
	CMD_MP3_PLAY,
	CMD_START_TRACE,
	CMD_STOP_TRACE,
	CMD_QUERY_BMS,
	CMD_QUERY_MP3,
	CMD_QUERY_CAR,
	CMD_LOCK_DOOR,
	CMD_DOOR_OPENED,
	CMD_DOOR_CLOSED,
	CMD_BRAKE_LOCKED,
	CMD_BRAKE_UNLOCKED,
	NULL
};

u32 g_need_ack = 0;

// DOOR Sta:
u8 g_door_state = 0;

// Door LOCK Sta:
// BIT7: 0-idle, 1-changed
// BIT0: 0-locked, 1-unlocked
u8 g_drlock_sta_chged = 0;

// Door Open/Close Sta:
// BIT7: 0-idle, 1-changed
// BIT0: 0-closed, 1-opened
u8 g_dropen_sta_chged = 0;

// HandBrake LOCK Sta:
// BIT7: 0-idle, 1-changed
// BIT0: 0-locked, 1-unlocked
u8 g_hbrake_sta_chged = 0;

u16 g_gps_trace_gap = 0;

u8 g_server_time[LEN_SYS_TIME+1] = "";

u8 g_iap_update = 0;
u8 g_iap_update_md5[LEN_DW_MD5+1]   = "";
u8 g_iap_update_url[LEN_DW_URL+1] = "";

u8 g_hbeat_gap = 6;// default 6s

u8 g_mp3_play_name[LEN_FILE_NAME+1];

u8 is_supported_mobit_cmd(u8 cnt, char* str)
{
	u8 i = 0;

	for (i=0; i<cnt; i++) {
		if (0 == strncmp(str, cmd_list[i], strlen(cmd_list[i]))) {
			break;
		}
	}

	if (i != UNKNOWN_CMD) {
		printf("Recved CMD/ACK %s\n", str);
	}

	return i;
}

u8 get_mobit_cmd_count()
{
	u8 cnt = 0;
	while(1) {
		if (NULL == cmd_list[cnt]) {
			break;
		}
		cnt++;
	}

	return cnt;
}

void parse_mobit_msg(char* msg)
{
    int index = 0;
	int data_pos = 0;
	char delims[] = ",";
	char* split_str = NULL;

	enum CMD_TYPE cmd_type = UNKNOWN_CMD;

	u8 cmd_count = get_mobit_cmd_count();

#ifdef DEBUG_USE
	//printf("Support %d CMDs\n", cmd_count);
#endif

	split_str = strtok(msg, delims);
	while(split_str != NULL) {
#ifdef DEBUG_USE
		//printf("split_str = %s\n", split_str);
#endif
		// index = 3: SVR CMD
		// index = 4: SVR ACK
		if ((3 == index) || (4 == index)) {
			if (UNKNOWN_CMD == cmd_type) {
				cmd_type = (enum CMD_TYPE)is_supported_mobit_cmd(cmd_count, split_str);

				if (strstr((const char*)msg, (const char*)"B5")) {
					g_door_state = 0;
				}
				
				if (cmd_type != UNKNOWN_CMD) {
					if (0 == data_pos) {
						data_pos = index;
						// printf("data_pos = %d, cmd_type = %d\n", data_pos, cmd_type);
					}

					// No need Parse extra params
                    if (UNLOCK_DOOR == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (ENGINE_START == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (LOCK_DOOR == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (QUERY_PARAMS == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (QUERY_CAR == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (DEV_SHUTDOWN == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (QUERY_GPS == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (QUERY_BMS == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (QUERY_MP3 == cmd_type) {
                        g_need_ack |= (1<<cmd_type);
                    } else if (STOP_TRACE == cmd_type) {
						g_gps_trace_gap = 0;
						printf("g_gps_trace_gap = %d\n", g_gps_trace_gap);
						
						g_need_ack |= (1<<cmd_type);
					} else if (HEART_BEAT == cmd_type) {
        				// Do nothing
					} else if (DOOR_LOCKED == cmd_type) {
                        g_drlock_sta_chged &= 0x7F;
                        //printf("recved DOOR_LOCKED ACK from Server\n");
					} else if (DOOR_UNLOCKED == cmd_type) {
                        g_drlock_sta_chged &= 0x7F;
                        //printf("recved DOOR_UNLOCKED ACK from Server\n");
					} else if (DOOR_OPENED == cmd_type) {
                        g_dropen_sta_chged &= 0x7F;
                        //printf("recved DOOR_OPENED ACK from Server\n");
					} else if (DOOR_CLOSED == cmd_type) {
                        g_dropen_sta_chged &= 0x7F;
                        //printf("recved DOOR_CLOSED ACK from Server\n");
					} else if (BRAKE_LOCKED == cmd_type) {
                        g_hbrake_sta_chged &= 0x7F;
                        //printf("recved BRAKE_LOCKED ACK from Server\n");
					} else if (BRAKE_UNLOCKED == cmd_type) {
                        g_hbrake_sta_chged &= 0x7F;
                        //printf("recved BRAKE_UNLOCKED ACK from Server\n");
					}
				} else {// Maybe Re, So Can Not break
					// break;
				}
			}
		}

		// Parse CMD or ACK
		// Need to Parse extra params
		if (index > data_pos) {
			if (DEV_REGISTER == cmd_type) {
				if (5 == index) {
					strncpy((char*)g_server_time, split_str, LEN_SYS_TIME);
					g_server_time[LEN_SYS_TIME] = '\0';
					printf("g_server_time = %s\n", g_server_time);
					//RTC_Sync_time(g_server_time);
				} else if (6 == index) {
                    //g_time_start_hbeat = os_jiffies;
					g_hbeat_gap = atoi(split_str);
					printf("g_hbeat_gap = %d\n", g_hbeat_gap);
                    if (g_hbeat_gap < 5) {
                        g_hbeat_gap = 5;
                        printf("change g_hbeat_gap = %d\n", g_hbeat_gap);
                    }
				}
			} else if (IAP_UPGRADE == cmd_type) {
				g_iap_update = 1;
				memset(g_iap_update_url, 0, LEN_DW_URL);
				strncpy((char*)g_iap_update_url, split_str, LEN_DW_URL);
				printf("g_iap_update_url = %s\n", g_iap_update_url);
				
				g_need_ack |= (1<<cmd_type);
			} else if (MP3_PLAY == cmd_type) {
				memset(g_mp3_play_name, 0, LEN_FILE_NAME);
				strncpy((char*)g_mp3_play_name, split_str, LEN_FILE_NAME);
				printf("g_mp3_play_name = %s\n", g_mp3_play_name);
				
				g_need_ack |= (1<<cmd_type);
			} else if (MP3_UPDATE == cmd_type) {
				if (4 == index) {
					//memset(g_mp3_update_name, 0, LEN_FILE_NAME);
					//strncpy((char*)g_mp3_update_name, split_str, LEN_FILE_NAME);
					//printf("g_mp3_update_name = %s\n", g_mp3_update_name);
				} else if (5 == index) {
					//memset(g_mp3_update_url, 0, LEN_DW_URL);
					//g_mp3_update = 1;
					//strncpy((char*)g_mp3_update_url, split_str, LEN_DW_URL);
					//printf("g_mp3_update_url = %s\n", g_mp3_update_url);
				}
			} else if (START_TRACE == cmd_type) {
                //g_time_start_gps = os_jiffies;
				//g_gps_trace_gap = atoi(split_str);
				//printf("g_gps_trace_gap = %d\n", g_gps_trace_gap);
                //if (g_gps_trace_gap < 5) {
                //    g_gps_trace_gap = 5;
                //    printf("change g_gps_trace_gap = %d\n", g_gps_trace_gap);
                //}

				g_need_ack |= (1<<cmd_type);
			} else if (RING_ALARM == cmd_type) {
				//g_ring_times = atoi(split_str);
				//printf("g_ring_times = %d\n", g_ring_times);

				g_need_ack |= (1<<cmd_type);
			} else if (JUMP_LAMP == cmd_type) {
				//g_lamp_times = atoi(split_str);
				//printf("g_lamp_times = %d\n", g_lamp_times);

				g_need_ack |= (1<<cmd_type);
			}
		}
		split_str = strtok(NULL, delims);
		if ((NULL==split_str) && (MP3_UPDATE==cmd_type) && (4==index)) {
			//if url NULL -> delete file
			//u8 mp3_file[LEN_FILE_NAME+1] = "";
			//sprintf((char*)mp3_file, "0:/MUSIC/%s.mp3", g_mp3_update_name);
			//f_unlink((const char*)mp3_file);
			//printf("%s deleted\n", mp3_file);
		}
		index++;
	}
}
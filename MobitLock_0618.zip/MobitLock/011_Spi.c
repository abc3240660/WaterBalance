
#include <p24fxxxx.h> 
#include "---_Variables.h"
#include "011_Spi.h"

#define MOSI    _LATG8      //PR21,SDO2,10
#define MISO    _RG7       //PR26,PG7
#define SCK     _LATG6      //PR21,SCK2,11
#define CS1     _LATE7


#define TMOSI   _TRISG8
#define TMISO   _TRISG7
#define TSCK    _TRISG6
#define TCS1    _TRISE7


extern VAR Mobit;
extern NonVolatile NonVolatileDATA;

void clrc663_SPI_init(void)
{
    CS1 = 1;
    SCK = 0;
    MOSI = 0;    
    MISO = 1;

    CS1 = 1;
    TSCK = 0;
    TMOSI = 0;
    TMISO = 1;
    
    _RP21R = 11 ;
    _RP19R = 10 ; 
    _SDI2R = 26;
    
    SPI2CON1 = 0x0122;      
    SPI2CON2 = 0x0000;         
#if 0// temp commented
    SPI2STAT = 0X8000;
#endif

    CM2CON = 0 ;
#if 0// temp commented
    ODCEbits.ODE7 = 1;
    AD1PCFGL |= 0x0080;
#endif
    LATE |= 0XFF7F;
    TRISE &= 0XFF7F;
}
unsigned char clrc663_SPI_write(unsigned char data)
{
    unsigned char temp = 0;
#if 0// temp commented
    SPI2BUF = data;
#endif
    while(_SPI2IF == 0);    
    while(SCK == 1);
#if 0// temp commented
    temp = SPI2BUF; 
#endif
    _SPI2IF = 0;
    return(temp);
}
void clrc663_SPI_transfer(const unsigned char * tx, unsigned char* rx, unsigned int len)
{
    int i = 0;
    for(i=0;i<len;i++){
        rx[i] = clrc663_SPI_write(tx[i]); 
    }
}

void clrc663_SPI_select(void)
{
    CS1 = 0;
}

void clrc663_SPI_unselect(void)
{
    CS1 = 1;
}
//******************************************************************************
//* END OF FILE
//******************************************************************************

#ifndef __MOBIT_PROTOCOL_H
#define __MOBIT_PROTOCOL_H

#include "003_BG96.h"

#define PROTOCOL_HEAD	"^MOBIT"
#define DEV_TAG			"ECAR"
#define SW_VERSION		"V201903182110"
#define HW_VERSION		"V1.0"

#define CMD_DEV_ACK		"Re"// DEV ACK

// F407 Send to Server automatically
#define CMD_DEV_REGISTER	"R0"// DEV Host
#define CMD_HEART_BEAT		"H0"// DEV Host
#define CMD_DOOR_LOCKED		"C1"// DEV Host
#define CMD_DOOR_UNLOCKED	"O1"// DEV Host
#define CMD_CALYPSO_UPLOAD	"C3"// DEV Host
#define CMD_INVALID_MOVE	"W1"// DEV Host
#define CMD_REPORT_GPS		"L1"// DEV Host
#define CMD_IAP_SUCCESS		"U1"// DEV Host
#define CMD_CHARGE_STARTED	"B1"// DEV Host
#define CMD_CHARGE_STOPED	"B3"// DEV Host
#define CMD_DOOR_OPENED 	"C7"// DEV Host
#define CMD_DOOR_CLOSED 	"C9"// DEV Host
#define CMD_BRAKE_LOCKED	"B5"// DEV Host
#define CMD_BRAKE_UNLOCKED	"B7"// DEV Host

// F407 Recv from Server and Action / ACK
#define CMD_QUERY_PARAMS	"C0"// DEV ACK
#define CMD_RING_ALARM		"R2"// DEV ACK
#define CMD_UNLOCK_DOOR		"O0"// DEV ACK
#define CMD_JUMP_LAMP		"S2"// DEV ACK
#define CMD_ENGINE_START	"E0"// DEV ACK
#define CMD_DEV_SHUTDOWN    "S0"// DEV ACK
#define CMD_QUERY_GPS   	"L0"// DEV ACK
#define CMD_IAP_UPGRADE   	"U0"// DEV ACK
#define CMD_MP3_UPDATE  	"U2"// DEV ACK
#define CMD_MP3_PLAY    	"P0"// DEV ACK
#define CMD_START_TRACE   	"T0"// DEV ACK
#define CMD_STOP_TRACE   	"T2"// DEV ACK
#define CMD_QUERY_BMS   	"B0"// DEV ACK
#define CMD_QUERY_MP3   	"P2"// DEV ACK
#define CMD_QUERY_CAR   	"C4"// DEV ACK
#define CMD_LOCK_DOOR   	"C6"// DEV ACK

#define LEN_SYS_TIME    32
#define LEN_IMEI_NO     32
#define LEN_BAT_VOL     32
#define LEN_RSSI_VAL    32
#define LEN_MAX_SEND    1024
#define LEN_MAX_RECV    32
#define LEN_DW_MD5      32
#define LEN_DW_URL      128
#define LEN_FILE_NAME   128

enum CMD_TYPE {
	DEV_REGISTER = 0,
	HEART_BEAT,
	QUERY_PARAMS,
	RING_ALARM,
	UNLOCK_DOOR,
	DOOR_LOCKED,
	DOOR_UNLOCKED,
	JUMP_LAMP,
	CALYPSO_UPLOAD,
	ENGINE_START,
	INVALID_MOVE,
	REPORT_GPS,
	IAP_SUCCESS,
	CHARGE_STARTED,
	CHARGE_STOPED,
	DEV_SHUTDOWN,
	QUERY_GPS,
	IAP_UPGRADE,
	MP3_UPDATE,
	MP3_PLAY,
	START_TRACE,
	STOP_TRACE,
	QUERY_BMS,
	QUERY_MP3,
	QUERY_CAR,
	LOCK_DOOR,
	DOOR_OPENED,
	DOOR_CLOSED,
	BRAKE_LOCKED,
	BRAKE_UNLOCKED,
	UNKNOWN_CMD
};

void parse_mobit_msg(char* msg);

#endif

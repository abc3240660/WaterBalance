//       10        20        30        40        50        60        70
//--*----*----*----*----*----*----*----*----*----*----*----*----*----*----*----*

/******************************************************************************
 * A library for PIC24F GPIO Configuration
 * This file is about the GPIO API of PIC24
 *
 * Copyright (c) 2019 Mobit technology inc.
 * @Author       : Damon
 * @Create time  : 03/11/2019
******************************************************************************/

#include <stdio.h>

#include <p24fxxxx.h>

#include "006_Gpio.h"

void GPIOB_Init(void)
{
    CM2CON = 0;
    ODCB &= 0xFFF0;
    // AD1PCFGL |= 0x000F;
    LATB |= 0X000F;   
    TRISB &= 0XFFF0;
}

void GPIOB_SetPin(short pin,char value)
{
    if(value){
        PORTB |= (0x0001<<pin);
    }else{
        PORTB &= (~0x0001<<pin);
    }
}

void connect_test(const ip_addr_t *ipaddr);
void dns_test(void);
void tcp_tester_init(void);
void udp_tester_init(void);
void display_time(void);
